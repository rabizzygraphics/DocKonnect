<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Staff Page</title>
    <link
      rel="stylesheet"
      href="https://unicons.iconscout.com/release/v4.0.0/css/line.css"
    />

    <link rel="stylesheet" href="css/staffstyle.css" />
  </head>
  <body>
    <nav>
      <img src="images/logo.jpg" alt="" class="logo">
      <ul class="list">
          <li><a href="index.php">Home</a></li>
          <li><a href="staff.php">Service</a></li>
          <li><a href="docpro.php">Doctors</a></li>
          <li><a href="staff.php">Staff</a></li>
      </ul>

      <div class="butt">
          <div class="login">
            <a href="login.php">  Login</a>
          </div>
          <div class="signup">
             <a href="signup.php"> Join Us </a>
          </div>
      </div>
  </nav>

    <section class="container">
      <div class="title">
        <h1>Our People</h1>
        <p>
          Our dedicated staff comprises compassionate professionals committed to delivering exceptional care.
        </p>
      </div>

      <div class="cards">
        <div class="card">
          <span><img src="images/sen.jpg" alt="" height="105px" /></span>
          <h2>Rosemary Honuvor</h2>
          <p>Senior Partner</p>
          <div class="socials">
            <a href=""><i class="uil uil-facebook"></i></a>
            <a href=""><i class="uil uil-instagram"></i></a>
            <a href=""><i class="uil uil-twitter-alt"></i></a>
          </div>
        </div>

        <div class="card">
          <span><img src="images/phil.jpg" alt="" height="115px" /></span>
          <h2>Philemon Ansah</h2>
          <p>Senior Partner</p>
          <div class="socials">
            <a href=""><i class="uil uil-facebook"></i></a>
            <a href=""><i class="uil uil-instagram"></i></a>
            <a href=""><i class="uil uil-twitter-alt"></i></a>
          </div>
        </div>

        <div class="card">
          <span><img src="images/pic7.jpg" alt="" height="115px"/></span>
          <h2>Kate Prempeh</h2>
          <p>Senior Partner</p>
          <div class="socials">
            <a href=""><i class="uil uil-facebook"></i></a>
            <a href=""><i class="uil uil-instagram"></i></a>
            <a href=""><i class="uil uil-twitter-alt"></i></a>
          </div>
        </div>

        <div class="card">
          <span><img src="images/bob.jpg" alt="" height="115px" /></span>
          <h2>Robert Aglago</h2>
          <p>Senior Partner</p>
          <div class="socials">
            <a href=""><i class="uil uil-facebook"></i></a>
            <a href=""><i class="uil uil-instagram"></i></a>
            <a href=""><i class="uil uil-twitter-alt"></i></a>
          </div>
        </div>

        <div class="card">
          <span><img src="images/emm.jpg" alt="" height="115px" /></span>
          <h2>Emmanuel Dzitorwoko</h2>
          <p>Senior Partner</p>
          <div class="socials">
            <a href=""><i class="uil uil-facebook"></i></a>
            <a href=""><i class="uil uil-instagram"></i></a>
            <a href=""><i class="uil uil-twitter-alt"></i></a>
          </div>
        </div>

        <div class="card">
          <span><img src="images/benice.jpg" alt="" height="115px" /></span>
          <h2>Bernice  Essel</h2>
          <p>Senior Partner</p>
          <div class="socials">
            <a href=""><i class="uil uil-facebook"></i></a>
            <a href=""><i class="uil uil-instagram"></i></a>
            <a href=""><i class="uil uil-twitter-alt"></i></a>
          </div>
        </div>

        <div class="card">
          <span><img src="images/delly.jpg" alt="" height="115px"/></span>
          <h2>Derrick Acheampong</h2>
          <p>Senior Partner</p>
          <div class="socials">
            <a href=""><i class="uil uil-facebook"></i></a>
            <a href=""><i class="uil uil-instagram"></i></a>
            <a href=""><i class="uil uil-twitter-alt"></i></a>
          </div>
        </div>

        <div class="card">
          <span><img src="images/benj.jpg" alt="" height="115px"/></span>
          <h2>Benjamin Awortwe</h2>
          <p>Senior Partner</p>
          <div class="socials">
            <a href=""><i class="uil uil-facebook"></i></a>
            <a href=""><i class="uil uil-instagram"></i></a>
            <a href=""><i class="uil uil-twitter-alt"></i></a>
          </div>
        </div>
      </div>
    </section>
    <footer>
      <div class="det">
          <img src="images/logo.jpg" class="logo2">
          <p class="legal">Copyright-Suite</p>
          <div class="icons">
              <img src="images/facebook.png" class="i1">
              <img src="images/twitt.png" class="i2">
              <img src="images/insta.jpeg" class="i3">
          </div>

      </div>
  </footer>
  </body>
</html>
