
<!DOCTYPE html>
<html>
<head>
    <title>APPOINTMENT FORM</title>
    <link rel="stylesheet"  type="text/css" href="css/appformstyle.css">
</head>
<body>
 
    
    <form method="post" action="process_form.php">
        <label for="first_name">First Name:</label>
        <input type="text" id="first_name" name="first_name" required><br><br>

        <label for="middle_initial">Middle Initial:</label>
        <input type="text" id="middle_initial" name="middle_initial"><br><br>

        <label for="last_name">Last Name:</label>
        <input type="text" id="last_name" name="last_name" required><br><br>

        <label for="birth_date">Birth Date:</label>
        <input type="date" id="birth_date" name="birth_date" required><br><br>

        <label for="phone">Daytime Phone:</label>
        <input type="tel" id="phone" name="phone" required><br><br>

        <label for="first_visit">Is this your first visit to the office?</label>
        <input type="radio" id="first_visit_yes" name="first_visit" value="Yes">Yes
        <input type="radio" id="first_visit_no" name="first_visit" value="No">No<br><br>

        <label for="appointment_date">Appointment Date:</label>
        <input type="date" id="appointment_date" name="appointment_date" required><br><br>
<label for="appointment_time">Appointment Time:</label>
        <input type="time" id="appointment_time" name="appointment_time" required><br><br>

        <label for="department">
        <select id="department">
  <option value="">Select Department</option>
  <option value="cardiology">Cardiology</option>
  <option value="neurology">Neurology</option>
  <option value="orthopedics">Orthopedics</option>
</select>

<select id="doctor">
  <option value="">Select Doctor</option>
 
</select><br><br>

<script>
  const departmentDropdown = document.getElementById('department');
  const doctorDropdown = document.getElementById('doctor');

  departmentDropdown.addEventListener('change', function() {
    doctorDropdown.innerHTML = ''; // Clear previous options

    const selectedDepartment = departmentDropdown.value;

    switch(selectedDepartment) {
      case 'cardiology':
        addDoctors(['Dr. Rose', 'Dr. Bernice', 'Dr. Philemon']);
        break;
      case 'neurology':
        addDoctors(['Dr. Francisca', 'Dr. Emmanuel', 'Dr. Kate']);
        break;
      case 'orthopedics':
        addDoctors(['Dr. Robert', 'Dr. Derrick', 'Dr. Legacy']);
        break;
      default:
        doctorDropdown.innerHTML = '<option value="">Select Doctor</option>';
        break;
    }
  });

  function addDoctors(doctors) {
    doctors.forEach(function(doctor) {
      const option = document.createElement('option');
      option.value = doctor;
option.text = doctor;
      doctorDropdown.appendChild(option);
    });
  }
</script>


<label for="symptoms">
<label for="symptoms">Symptoms:</label>
    
<textarea id="symptoms" rows="4" cols="50"></textarea><br><br>


<button>Book appointment</button><br><br>
</label>
</label>
</form>

</body>
</html>
