<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dockonnect";

// Retrieve form data
$first_name = $_POST['first_name'];
$middle_initial = $_POST['middle_initial'];
$last_name = $_POST['last_name'];
$birth_date = $_POST['birth_date'];
$appointment_date = $_POST['appointment_date'];
$appointment_time = $_POST['appointment_time'];
$symptoms = $_POST['symptoms'];

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);


// Prepare and execute the SQL query to insert the data
$sql = "INSERT INTO appointmentBooking (first_name, middle_initial, last_name, birth_date, appointment_date, appointment_time, symptoms) 
        VALUES ('$first_name', '$middle_initial', '$last_name', '$birth_date', '$appointment_date', '$appointment_time', '$symptoms')";

if ($conn->query($sql) === TRUE) {
    echo "Appointment Booked successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Redirect to the homepage
header("Location: main.php");
exit;
// Close the database connection
$conn->close();
?>