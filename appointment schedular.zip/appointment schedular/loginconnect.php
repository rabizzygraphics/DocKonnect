<?php
// Establish connection to the database
$servername = "localhost";
$username = "root"; // Assuming the default username is "root"
$password = "";
$dbname = "dockonnect";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process login form data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Validate the user's login credentials
    $sql = "SELECT * FROM signup WHERE email='$email' AND pass_word='$password'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        // Login successful
        // Add the user_id to the login table
        $user = $result->fetch_assoc();
        $user_id = $user['id'];
        $insert_login_sql = "INSERT INTO login (user_id) VALUES ('$user_id')";
        $conn->query($insert_login_sql);

        // Redirect to the homepage
        header("Location: main.php");
        exit;
    } else {
        // Login failed
        echo "Invalid email or password. Try again!";
    }
}

// Close the database connection
$conn->close();
?>