<!DOCTYPE html>
<html>

<head>
  <title>DOCTORS PROFILE</title>
  <link rel="stylesheet" href="css/docstyle.css" />
</head>

<body>
  <nav>
    <img src="images/logo.jpg" alt="" class="logo">
    <ul class="list">
        <li><a href="index.php">Home</a></li>
        <li><a href="service.php">Service</a></li>
        <li><a href="docpro.php">Doctors</a></li>
        <li><a href="staff.php">Staff</a></li>
    </ul>

    <div class="butt">
        <div class="login">
          <a href="login.php">  Login</a>
        </div>
        <div class="signup">
           <a href="signup.php"> Join Us </a>
        </div>
    </div>
</nav>
  <section class="services" id="services">
    <div class="content">
      <div class="title"><span>DOCTORS PROFILE</span></div>
      <div class="boxes">
        <div class="box">
          <div class="img"><img src="images/luca.jpg" alt="img" draggable="false"></div>
          <div class="title">Dr. Luca William</div>
          <h3>
            <font color="blue">DENTIST</font><br>TEMA GENERAL HOSPITAL
          </h3>
          <div class="button">
            <button>Availability</button><a href="tel:+233242858727"> <button>Make A Call</button></a>
          </div>
        </div>
        <div class="box">
          <div class="img"><img src="images/doc11.jpg" alt="img" draggable="false"></div>
          <div class="title">Dr. Maxwell Freeman</div>
          <h3>
            <font color="blue">DENTIST</font><br>37 HOSPITAL
          </h3>
          <div class="button">
            <button>Availability</button><a href="tel:+233501025310"> <button>Make A Call</button></a>
          </div>
        </div>
        <div class="box">
          <div class="img"><img src="images/doc3.jpg" alt="img" draggable="false"></div>
          <div class="title">Dr. Iqbal John</div>
          <h3>
            <font color="blue">DENTIST</font><br>BENGALI HOSPITAL
          </h3>
          <div class="button">
            <button>Availability</button><a href="tel:+233231025310"> <button>Make A Call</button></a>
          </div>
        </div>
        <div class="box">
          <div class="img"><img src="images/doc2.jpg" alt="img" draggable="false"></div>
          <div class="title">Dr. PHILEMON</div>
          <h3>
            <font color="blue">DENTIST</font><br>CRYSTAL HOSPITAL
          </h3>
          <div class="button">
            <button>Availability</button><a href="tel:+233501025325"> <button>Make A Call</button></a>
          </div>
        </div>
        <div class="box">
          <div class="img"><img src="images/will.jpg" alt="img" draggable="false"></div>
          <div class="title">Dr. David William</div>
          <h3>
            <font color="blue">DENTIST</font><br>BENGALI HOSPITAL
          </h3>
          <div class="button">
            <button>Availability</button><a href="tel:+233502325040"> <button>Make A Call</button></a>
          </div>
        </div>
        <div class="box">
          <div class="img"><img src="images/docpic1.jpg" alt="img" draggable="false"></div>
          <div class="title">Dr. ROBERT</div>
          <h3>
            <font color="blue">DENTIST</font><br>TEMA GENERAL HOSPITAL
          </h3>
          <div class="button">
            <button>Availability</button><a href="tel:+233501025310"> <button>Make A Call</button></a>
          </div>
        </div>
        <div class="box">
          <div class="img"><img src="images/docpic10.jpg" alt="img" draggable="false"></div>
          <div class="title">Dr. RICHFRED</div>
          <h3>
            <font color="blue">DENTIST</font><br>SEKONDI HOSPITAL
          </h3>
          <div class="button">
            <button>Availability</button><a href="tel:+233501025310"> <button>Make A Call</button></a>
          </div>
        </div>
        <div class="box">
          <div class="img"><img src="images/docpic11.jpg" alt="img" draggable="false"></div>
          <div class="title">Dr. JOHN</div>
          <h3>
            <font color="blue">DENTIST</font><br>SEKONDI HOSPITAL
          </h3>
          <div class="button">
            <button>Availability</button><a href="tel:+233501025310"> <button>Make A Call</button></a>
          </div>
        </div>
        <div class="box">
          <div class="img"><img src="images/docpic12.jpg" alt="img" draggable="false"></div>
          <div class="title">Dr. AMOS</div>
          <h3>
            <font color="blue">DENTIST</font><br>CRYSTAL HOSPITAL
          </h3>
          <div class="button">
            <button>Availability</button><a href="tel:+233501025310"> <button>Make A Call</button></a>
          </div>
        </div>
        <div class="box">
          <div class="img"><img src="images/docpic13.jpg" alt="img" draggable="false"></div>
          <div class="title">Dr. PHILLIP</div>
          <h3>
            <font color="blue">DENTIST</font><br>TEMA GENERAL HOSPITAL
          </h3>
          <div class="button">
            <button>Availability</button><a href="tel:+233501025310"> <button>Make A Call</button></a>
          </div>
        </div>
        <div class="box">
          <div class="img"><img src="images/docpic14.jpg" alt="img" draggable="false"></div>
          <div class="title">Dr. OSEI</div>
          <h3>
            <font color="blue">DENTIST</font><br>BENGALI HOSPITAL
          </h3>
          <div class="button">
            <button>Availability</button><a href="tel:+233501025310"> <button>Make A Call</button></a>
          </div>
        </div>
        <div class="box">
          <div class="img"><img src="images/docpic15.jpg" alt="img" draggable="false"></div>
          <div class="title">Dr. EMMANUAEL</div>
          <h3>
            <font color="blue">DENTIST</font><br>TEMA GENERAL HOSPITAL
          </h3>
          <div class="button">
            <button>Availability</button><a href="tel:+233501025310"> <button>Make A Call</button></a>
          </div>
        </div>
        <div class="box">
          <div class="img"><img src="images/docpic2.jpg" alt="img" draggable="false"></div>
          <div class="title">Dr. AIKINS</div>
          <h3>
            <font color="blue">DENTIST</font><br>CAPE COST HOSPITAL
          </h3>
          <div class="button">
            <button>Availability</button><a href="tel:+233501025310"> <button>Make A Call</button></a>
          </div>
        </div>
        <div class="box">
          <div class="img"><img src="images/docpic3.jpg" alt="img" draggable="false"></div>
          <div class="title">Dr. PHILEMON</div>
          <h3>
            <font color="blue">DENTIST</font><br>37 HOSPITAL
          </h3>
          <div class="button">
            <button>Availability</button><a href="tel:+233501025310"> <button>Make A Call</button></a>
          </div>
        </div>
        <div class="box">
          <div class="img"><img src="images/docpic4.jpg" alt="img" draggable="false"></div>
          <div class="title">Dr. JUDAS</div>
          <h3>
            <font color="blue">DENTIST</font><br>CRYSTAL HOSPITAL
          </h3>
          <div class="button">
            <button>Availability</button><a href="tel:+233501025310"> <button>Make A Call</button></a>
          </div>
        </div>
        <div class="box">
          <div class="img"><img src="images/docpic5.jpg" alt="img" draggable="false"></div>
          <div class="title">Dr. MENDS</div>
          <h3>
            <font color="blue">DENTIST</font><br>CRYSTAL HOSPITAL
          </h3>
          <div class="button">
            <button>Availability</button><a href="tel:+233501025310"> <button>Make A Call</button></a>
          </div>
        </div>
        <div class="box">
          <div class="img"><img src="images/docpic6.jpg" alt="img" draggable="false"></div>
          <div class="title">Dr. FRANCIS</div>
          <h3>
            <font color="blue">DENTIST</font><br>TEMA GENERAL HOSPITAL
          </h3>
          <div class="button">
            <button>Availability</button><a href="tel:+233501025310"> <button>Make A Call</button></a>
          </div>
        </div>
        <div class="box">
          <div class="img"><img src="images/docpic7 (2).jpg" alt="img" draggable="false"></div>
          <div class="title">Dr. ELVIS</div>
          <h3>
            <font color="blue">DENTIST</font><br>VOLTA HOSPITAL
          </h3>
          <div class="button">
            <button>Availability</button><a href="tel:+233501025310"> <button>Make A Call</button></a>
          </div>
        </div>
        <div class="box">
          <div class="img"><img src="images/docpic7.jpg" alt="img" draggable="false"></div>
          <div class="title">Dr. JOHN</div>
          <h3>
            <font color="blue">DENTIST</font><br>TEMA GENERAL HOSPITAL
          </h3>
          <div class="button">
            <button>Availability</button><a href="tel:+233501025310"> <button>Make A Call</button></a>
          </div>
        </div>
        <div class="box">
          <div class="img"><img src="images/docpic9.jpg" alt="img" draggable="false"></div>
          <div class="title">Dr. ISSAC</div>
          <h3>
            <font color="blue">DENTIST</font><br>37 HOSPITAL
          </h3>
          <div class="button">
            <button>Availability</button><a href="tel:+233501025310"> <button>Make A Call</button></a>
          </div>
        </div>
        <div class="box">
          <div class="img"><img src="images/docpic14.jpg" alt="img" draggable="false"></div>
          <div class="title">Dr. JUSTICE</div>
          <h3>
            <font color="blue">DENTIST</font><br>TEMA GENERAL HOSPITAL
          </h3>
          <div class="button">
            <button>Availability</button><a href="tel:+233501025310"> <button>Make A Call</button></a>
          </div>
        </div>
      </div>
    </div>
  </section>
  <footer>
    <div class="det">
        <img src="images/logo.jpg" class="logo2">
        <p class="legal">Copyright-Suite</p>
        <div class="icons">
            <img src="images/facebook.png" class="i1">
            <img src="images/twitt.png" class="i2">
            <img src="images/insta.jpeg" class="i3">
        </div>

    </div>
</footer>
</body>

</html>