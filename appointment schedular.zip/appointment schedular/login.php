<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
    integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="stylesheet" href="css/login.css">
    <title>Login Page</title>
</head>
<body>
    <div class="container">

        <!-- Login into your account -->
        <div class="left">
            <div class="content">
                <div class="logo">
                    <!-- <img src="" alt=""> -->
                    <h2>Doc Konnect</h2>
                </div>

                <h1 class="title">Log in to your Account</h1>
                <p >Welcome Back! Select method to log in:</p>

                <!-- Choose login  -->
                <div class="smedia">
                    <div class="google">
                        <img src="images/gg.png" alt="">
                        <a href="">Google</a>
                    </div>
                    <div class="fb">
                        <img src="images/fb (2).png" alt="">
                        <a href="">Facecook</a>
                    </div>
                </div>

                <p class="para">or continue with email</p>

                <!-- Form console --> 
                <form class="myform" action="login.php" method="post">
                    <input type="text" name="email" placeholder="Email" required>
                    <input type="password" name="password" placeholder="Password" minlength="8" maxlength="16" required>
                    
                    <div class="forgot_me">
                    <label for="remember">
                        <input type="checkbox" name="remember">&nbsp;Remember Me 
                    </label>
                    <a href="">Forgot Password?</a>
                    </div>
                    <button class="btn" type="submit" >Log in</button>

                    <p class="account">Don't have an account? &nbsp; <span><a class="account" href="signup.html">Create an account</a></span> </p>
                </form>
            </div>


        </div>  <!-- End of left -->

        <!-- Connect with your doctor -->
        <div class="right">
            <div class="content">
                    <div class="image" >
                        <img src="" alt="">
                        <div class="welcome">
                            <h2>Welcome to Doc Konnect</h2> <br>
                            <p class="" >This is where we connect you to your specialists</p>
                        </div>
                    </div>
            </div>
        </div>
    </div>
    
</body>
</html>