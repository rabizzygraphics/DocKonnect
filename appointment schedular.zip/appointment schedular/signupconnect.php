<?php
// Establish connection to the database
$servername = "localhost";
$username = "root"; // Assuming the default username is "root"
$password = "";
$dbname = "dockonnect";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process form data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = $_POST['name'];
    $email = $_POST['email'];
    $pass_word = $_POST['password'];
    $phone_number = $_POST['number'];
    $location = $_POST['location'];
    $gender = $_POST['gender'];

    // Perform validation
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Invalid email format";}
    elseif (!preg_match("/^[0-9]{10,13}$/", $phone_number)) {
        echo "Invalid phone number format";
    } else {
        // Insert data into the database
        $sql = "INSERT INTO signup (full_name, email, pass_word, phone_number, lo_cation, gender) VALUES ('$full_name', '$email', '$pass_word', '$phone_number', '$location', '$gender')";

        if ($conn->query($sql) === TRUE) {
            echo "New record created successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
    header("Location: login.php");
    exit;
}



// Close the database connection
$conn->close();
?>