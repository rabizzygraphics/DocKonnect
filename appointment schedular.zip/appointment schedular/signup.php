<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up Page</title>
    <link rel="stylesheet" href="css/signup.css">
</head>
<body>
    <div class="container">
        <div class="left">
            <div class="welcome">
                <p>We at Doc Konnect are always ready to <br>
                    connect you to your doctors 
                    for effective treatment.
                </p>
            </div>
        </div>



            <div class="right">
                <div class="createAc">
                    <h1>Create Account</h1>
                    <div class="smedia">
                        <div class="google">
                            <img src="images/gg.png" alt="">
                            <a href="">Sign up with Google</a>
                        </div>
                        <div class="fb">
                            <img src="images/fb (2).png" alt="">
                            <a href="">Sign up with Facebook</a>
                        </div>
                    </div>
                    <div class="hr">
                        <p>OR</p>
                    </div>

                    <!-- Form  -->
                    <form class="myform" action="signup.php" method="post">
                        <input type="text" name="name" placeholder="Full Name:" required>
                        <input type="email" name="email" placeholder="Email:" required>
                        <input type="password" name="password" id="" placeholder="Password:" minlength="8" maxlength="16" required>
                        <input type="tel" name="number" id="" maxlength="13" placeholder="Phone Number:" required>
                        <input type="text" name="location" id="" placeholder="Location:" required>
                        <label for="">Gender: &nbsp;&nbsp;
                        <input type="radio" name="gender" id="" value="Male" placeholder="Male" required> Male &nbsp;
                        <input type="radio" name="gender" id="" value="Female" placeholder="Female" required>Female
                        </label>
                        <button class="btn" >Create Account</button>
                        <p class="Already">Already have an account? <a class="Already" href="login.html">Log in</a></p>
                    </form>
                </div>
            </div>
    </div>
    
</body>
</html>