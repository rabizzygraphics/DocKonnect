<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DocKonnect</title>
    <link rel="stylesheet" href="css/indexstyle.css">
    <link rel="stylesheet" href="css/indexmedia.css">
</head>

<body>
    <main>
        <nav>
            <img src="images/logo.jpg" alt="" class="logo">
            <ul class="list">
                <li><a href="index.php">Home</a></li>
                <li><a href="service.php">Service</a></li>
                <li><a href="docpro.php">Doctors</a></li>
                <li><a href="staff.php">Staff</a></li>
            </ul>

            <div class="butt">
                <div class="login">
                  <a href="login.php">  Login</a>
                </div>
                <div class="signup">
                   <a href="signup.php"> Join Us </a>
                </div>
            </div>
        </nav>
        <div class="first">
            <div class="text">
                <h1 class="header">We Back You With a Smile for Ever</h1>
                <p class="para">Medical Recover is most focused in helping you discover your most beautiful smile</p>
                <div class="buttons">
                    <div class="tapp">
                      <a href="appform.php">  Take an Appointment</a>
                    </div>
                    <div class="lmore">
                      <a href="service.php">  Learn More</a>
                    </div>
                </div>
            </div>

            <img src="images/Images.png" alt="" id="man1">

        </div>
        <div class="third">
            <div class="sec">
                <img src="images/time.jpg" alt="" width="40px">
                <h3>24 Hour Service</h3>
                <p>Providing unwavering support around
                    the clock,our 24-hour service ensures.
                </p>
            </div>
            <div class="sec">
                <img src="images/doclogo.jpg" alt="" width="50px">
                <h3>Qualified Doctors</h3>
                <p>A qualified doctor possesses a comprehensive
                    understanding of medical sciences
                </p>
            </div>
            <div class="sec">
                <img src="images/ambulancelogo.jpg" alt="" width="50px">
                <h3>Emergency Care</h3>
                <p>It's timely intervention plays a crucial
                    role in stabilizing patients and saving lives.
                </p>
            </div>
            <div class="sec">
                <img src="images/otlogo.jpg" alt="" width="50px">
                <h3>Operation Theater</h3>
                <p>It is equipped with specialized tools
                    and technology to ensure the safety.
                </p>
            </div>
        </div>
        <div class="fourth">
            <div class="seek">
                <h2>10M</h2>
                <p>Happy Customers</p>
            </div>
            <div class="seek">
                <h2>04M</h2>
                <p>Monthly Visitors</p>
            </div>
            <div class="seek">
                <h2>120</h2>
                <p>Countries Worldwide</p>
            </div>
            <div class="seek">
                <h2>4.9</h2>
                <p>Trust Pilot</p>
            </div>
        </div>
        <div class="fifth">
            <div class="textt2">
                <h3>-WHO ARE WE</h3>
                <h1>We Help To Get Solutions</h1>
                <p>We specialize in providing tailored
                    solutions to address your unique challenges.
                    Let us be your partner in navigating complex
                    issues and finding effective resolutions.
                </p>
                <div class="lmore2">
                   <a href="service.php">Learn About</a> 
                </div>
            </div>
            <img src="images/femcom.jpg" alt="" id="femcom">
        </div>
        <div class="msg">
            <h3>Looking for Relief ?</h3>
            <p>
                Seeking a sanctuary where the burdens of the day dissipate,
                the heart finds reprieve,and the spirit rejuvenates.
            </p>
        </div>
        <div class="sixth">
            <h3>-TEAM</h3>
            <h1>Our Team</h1>
            <p>Empowering lives through knowledge,Our Team
                at the DocKonnect is dedicated to delivering
                accurate one click at a time.
            </p>
            <div class="team">
                <div class="detail">
                    <img src="images/teamdoc1.jpg" alt="" id="tim">
                    <h3>Sonia Alam</h3>
                    <p>Radiologist</p>
                    <div class="icons">
                        <img src="images/facebook.png" alt="" width="25px">
                        <img src="images/insta.jpeg" alt="" width="25px">
                        <img src="images/twitt.png" alt="" width="30px">
                    </div>
                </div>
                <div class="detail">
                    <img src="images/doc3.jpg" alt="" id="tim">
                    <h3>Iqbal John</h3>
                    <p>Phycologist</p>
                    <div class="icons">
                        <img src="images/facebook.png" alt="" width="25px">
                        <img src="images/insta.jpeg" alt="" width="25px">
                        <img src="images/twitt.png" alt="" width="30px">
                    </div>
                </div>
                <div class="detail">
                    <img src="images/will.jpg" alt="" id="tim">
                    <h3>David William</h3>
                    <p>EyeCare Specialist</p>
                    <div class="icons">
                        <img src="images/facebook.png" alt="" width="25px">
                        <img src="images/insta.jpeg" alt="" width="25px">
                        <img src="images/twitt.png" alt="" width="30px">
                    </div>
                </div>
                <div class="detail">
                    <img src="images/luca.jpg" alt="" id="tim">
                    <h3>Luca William</h3>
                    <p>SkinCare Specialist</p>
                    <div class="icons">
                        <img src="images/facebook.png" alt="" width="25px">
                        <img src="images/insta.jpeg" alt="" width="25px">
                        <img src="images/twitt.png" alt="" width="30px">
                    </div>
                </div>
            </div>
        </div>
        <div class="seven">
            <div class="one">
                <img src="images/Female.png" alt="" id="fm">
                <div class="one1">
                    <div class="ttt">
                    <h2>Choose Best Choose Us</h2>
                    <p>selecting the finest means choosing us-where excellence meets comitment.
                        Elevate your experience and outcomes with the best quality and service.
                    </p>
                </div>
                    <img src="images/arrow.jpg" alt=""  id="arrow">
                </div>
            </div>
            <div class="two">
                <h3>CHOOSE US</h3>
                <h1>Why Choose Us</h1>
                <div class="check">
                    <img src="images/check.jpg" alt="" width="60px" id="check">
                    <p>Safety is our first priority</p>
                </div>
                <div class="check">
                    <img src="images/check.jpg" alt="" width="60px" id="check">
                    <p>Flexibility treatement</p>
                </div>
                <div class="check">
                    <img src="images/check.jpg" alt="" width="60px" id="check">
                    <p>Diagnose with technology</p>
                </div>
                <div class="check">
                    <img src="images/check.jpg" alt="" width="60px" id="check">
                    <p>Reliable pricing</p>
                </div>
                <div class="check">
                    <img src="images/check.jpg" alt="" width="60px" id="check">
                    <p>Expert staff</p>
                </div>
                <div class="tap">
                  <a href="appform.html">  Take an appointment</a>
                </div>
            </div>
        </div>
        <div class="eight">
            <h3>-TESTIMONIALS</h3>
            <h2>What our Clients Say About Us </h2>
            <p>Our clients speak volumes about thier experiences with us, praising our exceptional service and unwavering commitment.</p>
            <div class="testimo">
                <div class="testimo-box">
                    <img src="images/tman1.jpg" alt="" width="60px" height="50px">
                    <div class="thin">
                        <h2>Sohail Williams</h2>
                        <h5>Back-end developer at Decojent</h5>
                        <p>Life-changing insights! This health website
                            empowered me to make informed choices for 
                            a healthier lifestyle
                        </p>
                        <h5>North America.2021.03.02</h5>
                    </div>
                </div>
                <div class="testimo-box">
                    <img src="images/tman2.jpg" alt="" width="60px" height="50px">
                    <div class="thin">
                        <h2>Anees khan</h2>
                        <h5>Engineer of Architecture</h5>
                        <p>Grateful for this resource!
                            The practical tips on the health website have 
                            been a game-changer for my well-being.
                        </p>
                        <h5>Central Asia.2021.03.02</h5>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <footer>
        <div class="det">
            <img src="images/logo.jpg" class="logo2">
            <p class="legal">Copyright-Suite</p>
            <div class="icons">
                <img src="images/facebook.png" class="i1">
                <img src="images/twitt.png" class="i2">
                <img src="images/insta.jpeg" class="i3">
            </div>

        </div>
    </footer>
</body>

</html>